# proton_db_api
Simple unofficial async ProtonDB API for Python 3.11+
